let DB = require("../config/conexao");
let conexao = new DB;
module.exports = function() {
    return {
        login: function(req) {
            var parameter = [req.body.user,req.body.password]
            conexao.execSQLQuery('SELECT id,user,nivel_acesso,email FROM user where user = ? and password = ?',parameter).then(function(result){
                if(result.length > 0){
                var id = result[0].id;
                var user = result[0].user;
                var email = result[0].email;
                var nivel_acesso = result[0].nivel_acesso;
                var token = jwt.sign({id,user,email,nivel_acesso}, process.env.SECRET, {
                expiresIn: 300 // expires in 5min
                });
                res.status(200).send({ auth: true, token: token });
                }else{
                res.status(500).send('Login inválido!');
                }
            })
        },
    };
};