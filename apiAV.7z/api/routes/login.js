module.exports = function(app) {
    var controller = app.controllers.login;
    app.route('v1/login')
        .post(controller.login)
  
}