var loginBO   = require('../../business/loginBO')();
module.exports = function() {
    return {
        login: function(req, res) {
            loginBO.login(req.query).then(function(login) {
                res.status(200).json(login);
            }, function(error) {
                res.status(500).json(error);
            });
        },

        delete: function(req, res) {
            loginBO.login(req.query).then(function(login) {
                res.status(200).json(login);
            }, function(error) {
                res.status(500).json(error);
            });
        }
    };

};