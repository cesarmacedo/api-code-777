var winston = require('winston');
        logger = winston.createLogger({
        level: 'info',
        format: winston.format.json(),
        transports: [
          new winston.transports.Console(),
          new winston.transports.File({ filename: 'logfile.log' })
        ]
    });
module.exports = winston;
