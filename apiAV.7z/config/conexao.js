const mysql = require('mysql');
let config = require('./settings');
require ("../helper/winston");
//require ('promisse')

class Conexao {
    execSQLQuery(sqlQry,parameters){
        return new Promise (function (resolve, reject){
            const connection = mysql.createConnection({
                host     : config.host,
                port     : config.port,
                user     : config.user,
                password : config.password,
                database : config.database
            });

            connection.query(sqlQry, parameters, function(error, results){
            logger.log('info', 'Iniciando conexão com banco');
                if(error) 
                reject(error);
                else
                logger.log('info', 'Consulta retornou',results);
                connection.end();
                logger.log('info', 'Finalizou a conexão com banco');
                resolve(results)
            });
        
        })
    }
}
module.exports = Conexao;